Spacewar is a single player space shooter. Fly throughout the universe dodging space rocks and fighting Enemy Space Ships!

CONTROLS:
A - Strafe Left
D - Strafe Right
W - Strafe Up
S - Strafe Down
Mouse Left Click - Shoot